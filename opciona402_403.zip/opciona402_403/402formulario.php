<?php
// Estos son los datos del formulario
$nombre = $_POST['nombre'] ?? '';
$email = $_POST['email'] ?? '';
$url = $_POST['url'] ?? '';
$sexo = $_POST['sexo'] ?? '';
$convivientes = $_POST['convivientes'] ?? '';
$aficiones = $_POST['aficiones'] ?? [];
$menu = $_POST['menu'] ?? [];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resumen formulario</title>
    <style>
        table { border-collapse: collapse; width: 50%; }
        td, th { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h2>Resumen de los datos enviados</h2>
    <table>
        <tr>
            <th>Campo</th>
            <th>Valor</th>
        </tr>
        <tr>
            <td>Nombre y apellidos</td>
            <td><?= htmlspecialchars($nombre) ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?= htmlspecialchars($email) ?></td>
        </tr>
        <tr>
            <td>URL página personal</td>
            <td><a href="<?= htmlspecialchars($url) ?>" target="_blank"><?= htmlspecialchars($url) ?></a></td>
        </tr>
        <tr>
            <td>Sexo</td>
            <td><?= htmlspecialchars($sexo) ?></td>
        </tr>
        <tr>
            <td>Número de convivientes</td>
            <td><?= htmlspecialchars($convivientes) ?></td>
        </tr>
        <tr>
            <td>Aficiones</td>
            <td><?= !empty($aficiones) ? implode(", ", array_map('htmlspecialchars', $aficiones)) : 'Ninguna' ?></td>
        </tr>
        <tr>
            <td>Menú favorito</td>
            <td><?= !empty($menu) ? implode(", ", array_map('htmlspecialchars', $menu)) : 'Ninguno' ?></td>
        </tr>
    </table>
</body>
</html>
